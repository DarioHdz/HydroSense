HydroSense v2.4.1 - Paquete de flasheo ESP32
===========================================

Este paquete contiene todos los archivos y scripts necesarios para flashear el sistema HydroSense v2.4.1 en una placa ESP32 mediante USB.

Contenido del paquete:
----------------------
- firmware.bin         → Código principal del sistema
- bootloader.bin       → Bootloader del ESP32
- partitions.bin       → Tabla de particiones personalizada
- boot_app0.bin        → Imagen auxiliar de arranque (obligatoria)
- flash_hydrosense.bat → Script de flasheo para Windows
- flash_hydrosense.sh  → Script de flasheo para Linux/macOS
- README.txt           → Este archivo con instrucciones

Requisitos:
-----------
- Python instalado
- `esptool.py` instalado (ejecuta `pip install esptool`)
- ESP32 conectado por USB
- Saber el puerto COM o dispositivo (ej. COM3 en Windows, /dev/ttyUSB0 en Linux)

Instrucciones:
--------------
1. Conecta el ESP32 por USB a tu computadora.
2. Presiona y mantén el botón **BOOT**, luego presiona y suelta el botón **EN** (RESET). Mantén BOOT presionado durante un segundo y luego suéltalo.
3. Ejecuta el script correspondiente a tu sistema operativo:

   En **Windows**:
   ----------------
   - Haz doble clic en `flash_hydrosense.bat`
   - Escribe el puerto COM cuando lo solicite (ej. COM3)

   En **Linux/macOS**:
   --------------------
   - Abre una terminal
   - Ve a la carpeta del proyecto
   - Dale permisos al script (solo una vez):
     ```bash
     chmod +x flash_hydrosense.sh
     ```
   - Ejecuta el script:
     ```bash
     ./flash_hydrosense.sh
     ```
   - Introduce el puerto cuando se te pida (ej. `/dev/ttyUSB0` o `/dev/tty.SLAB_USBtoUART`)

4. Espera a que el proceso finalice. Verás mensajes de éxito en consola.
5. Reinicia tu ESP32 y verifica el funcionamiento del sistema (salida serial, LEDs, Bluetooth).

Notas:
------
- Este procedimiento borra completamente el firmware anterior.
- No necesitas SPIFFS: este sistema usa microSD en FAT32 para configuración y almacenamiento.
- Asegúrate de usar una fuente confiable de alimentación (USB o batería estable).

Configuración inicial - config.json
===================================

Este sistema se configura automáticamente al inicio leyendo un archivo `config.json` desde la tarjeta microSD.

1. Inserta una tarjeta microSD **formateada en FAT32**.
2. Copia el archivo `config.json` incluido en este paquete a la **raíz** de la tarjeta (no dentro de carpetas).
3. Inserta la microSD en el ESP32 antes de encenderlo.
4. Al arrancar, el sistema leerá la configuración y comenzará a operar.

Puedes editar el archivo `config.json` con cualquier editor de texto, pero asegúrate de que:
- Use codificación UTF-8
- Mantenga el formato JSON válido (puedes validar online en [https://jsonlint.com](https://jsonlint.com))

Campos clave:
-------------
- `nombre_equipo`: nombre visible del dispositivo
- `intervalo_minutos`: tiempo entre mediciones
- `apn`, `usuario_apn`, `contrasena_apn`: datos del operador celular
- `numero_SMS`: número al que se envía alerta por fallo crítico
- `url_api`, `puerto_api`, `endpoint_api`: dirección del servidor web para envío de datos

Modifica los valores según tu instalación antes de insertar la microSD.
