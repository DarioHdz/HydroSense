#!/bin/bash

echo "=== HydroSense v2.4 ==="
echo "ESP32 - Flasheo manual para Linux/macOS"
echo "---------------------------------------"
echo "Asegúrate de conectar tu ESP32 y mantener presionado el botón BOOT mientras lo reinicias."
echo

read -p "Introduce el puerto (ej. /dev/ttyUSB0): " PORT
BAUD=460800

echo
echo "Iniciando flasheo en $PORT a $BAUD baudios..."
echo

esptool.py --chip esp32 --port $PORT --baud $BAUD write_flash -z \
  0x1000   bootloader.bin \
  0x8000   partitions.bin \
  0xe000   boot_app0.bin \
  0x10000  firmware.bin

echo
echo "✅ Flasheo completo."
